from flask import Flask, request, jsonify
import requests
import re
from threading import Thread
import time

app = Flask(__name__)

# NHTSA API endpoint for decoding VIN
NHTSA_API_URL = "https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/{vin}?format=json"

# In-memory database (for demonstration purposes)
vehicles_db = []  # Stores vehicle information
orgs_db = ["org1", "org2", "org3"]  # Example list of valid organizations

def decode_vin(vin):
    response = requests.get(NHTSA_API_URL.format(vin=vin))
    if response.status_code != 200:
        return None

    decoded_data = response.json().get("Results", [])
    if not decoded_data:
        return None

    vehicle_info = {
        "manufacturer": next((item['Value'] for item in decoded_data if item['Variable'] == "Manufacturer Name"), None),
        "model": next((item['Value'] for item in decoded_data if item['Variable'] == "Model"), None),
        "year": next((item['Value'] for item in decoded_data if item['Variable'] == "Model Year"), None)
    }

    return vehicle_info

@app.route('/vehicles', methods=['POST'])
def add_vehicle():
    data = request.json
    vin = data.get('vin')
    org = data.get('org')

    # Validate VIN (17 digit alpha-numeric string)
    if not re.match(r'^[A-HJ-NPR-Z0-9]{17}$', vin):
        return jsonify({"error": "Invalid VIN format"}), 400

    # Validate organization ID
    if org not in orgs_db:
        return jsonify({"error": "Organization ID not found"}), 400

    # Decode the VIN
    vehicle_info = decode_vin(vin)
    if vehicle_info is None:
        return jsonify({"error": "Failed to decode VIN"}), 400

    # Add the vehicle to the system
    vehicle_entry = {
        "vin": vin,
        "org": org,
        "manufacturer": vehicle_info['manufacturer'],
        "model": vehicle_info['model'],
        "year": vehicle_info['year']
    }
    vehicles_db.append(vehicle_entry)

    return jsonify(vehicle_entry), 201

@app.route('/vehicles/<vin>', methods=['GET'])
def get_vehicle(vin):
    # Validate VIN (17 digit alpha-numeric string)
    if not re.match(r'^[A-HJ-NPR-Z0-9]{17}$', vin):
        return jsonify({"error": "Invalid VIN format"}), 400

    # Find the vehicle in the database
    vehicle = next((v for v in vehicles_db if v["vin"] == vin), None)
    
    if vehicle is None:
        return jsonify({"error": "Vehicle not found"}), 404

    return jsonify(vehicle), 200

@app.route('/vehicles/decode/<vin>', methods=['GET'])
def decode_vin_endpoint(vin):
    # Validate VIN (17 digit alpha-numeric string)
    if not re.match(r'^[A-HJ-NPR-Z0-9]{17}$', vin):
        return jsonify({"error": "Invalid VIN format"}), 400

    # Decode the VIN
    vehicle_info = decode_vin(vin)
    if vehicle_info is None:
        return jsonify({"error": "Failed to decode VIN"}), 400

    return jsonify(vehicle_info), 200

if __name__ == '__main__':
    # Start the Flask app in a separate thread
    def run_server():
        app.run(debug=True, use_reloader=False)

    server_thread = Thread(target=run_server)
    server_thread.start()

    # Give the server a moment to start
    time.sleep(1)

    # Define the test VIN and org
    test_vin = "1HGCM82633A123456"
    test_org = "org1"

    # Add a vehicle (POST /vehicles)
    add_vehicle_data = {
        "vin": test_vin,
        "org": test_org
    }
    add_vehicle_response = requests.post("http://127.0.0.1:5000/vehicles", json=add_vehicle_data)
    print("POST /vehicles Response Status Code:", add_vehicle_response.status_code)
    print("POST /vehicles Response JSON:", add_vehicle_response.json())

    # Decode a VIN (GET /vehicles/decode/:vin)
    decode_vin_response = requests.get(f"http://127.0.0.1:5000/vehicles/decode/{test_vin}")
    print("GET /vehicles/decode/:vin Response Status Code:", decode_vin_response.status_code)
    print("GET /vehicles/decode/:vin Response JSON:", decode_vin_response.json())

    # Fetch vehicle details (GET /vehicles/:vin)
    get_vehicle_response = requests.get(f"http://127.0.0.1:5000/vehicles/{test_vin}")
    print("GET /vehicles/:vin Response Status Code:", get_vehicle_response.status_code)
    print("GET /vehicles/:vin Response JSON:", get_vehicle_response.json())