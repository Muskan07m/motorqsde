import requests

# NHTSA API endpoint for decoding VIN
NHTSA_API_URL = "https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/{vin}?format=json"

def decode_vin(vin):
    # Make the API request to NHTSA to decode the VIN
    response = requests.get(NHTSA_API_URL.format(vin=vin))

    if response.status_code != 200:
        print("Failed to decode VIN")
        return

    # Parse the response to extract manufacturer, model, and year
    decoded_data = response.json().get("Results", [])
    if not decoded_data:
        print("Invalid VIN")
        return

    vehicle_info = {
        "manufacturer": next((item['Value'] for item in decoded_data if item['Variable'] == "Manufacturer Name"), None),
        "model": next((item['Value'] for item in decoded_data if item['Variable'] == "Model"), None),
        "year": next((item['Value'] for item in decoded_data if item['Variable'] == "Model Year"), None)
    }

    # Print vehicle info to the console
    print(f"Vehicle info: {vehicle_info}")

if __name__ == '__main__':
    # Example VIN to decode
    vin = "1HGCM82633A123456"
    decode_vin(vin)
