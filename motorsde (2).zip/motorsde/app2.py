from flask import Flask, request, jsonify
import requests
import re

app = Flask(__name__)

# NHTSA API endpoint for decoding VIN
NHTSA_API_URL = "https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/{vin}?format=json"

# In-memory database (for demonstration purposes)
vehicles_db = []  # Stores vehicle information
orgs_db = ["org1", "org2", "org3"]  # Example list of valid organizations

def decode_vin(vin):
    response = requests.get(NHTSA_API_URL.format(vin=vin))
    if response.status_code != 200:
        return None

    decoded_data = response.json().get("Results", [])
    if not decoded_data:
        return None

    vehicle_info = {
        "manufacturer": next((item['Value'] for item in decoded_data if item['Variable'] == "Manufacturer Name"), None),
        "model": next((item['Value'] for item in decoded_data if item['Variable'] == "Model"), None),
        "year": next((item['Value'] for item in decoded_data if item['Variable'] == "Model Year"), None)
    }

    return vehicle_info

@app.route('/vehicles', methods=['POST'])
def add_vehicle():
    data = request.json
    vin = data.get('vin')
    org = data.get('org')

    # Validate VIN (17 digit alpha-numeric string)
    if not re.match(r'^[A-HJ-NPR-Z0-9]{17}$', vin):
        return jsonify({"error": "Invalid VIN format"}), 400

    # Validate organization ID
    if org not in orgs_db:
        return jsonify({"error": "Organization ID not found"}), 400

    # Decode the VIN
    vehicle_info = decode_vin(vin)
    if vehicle_info is None:
        return jsonify({"error": "Failed to decode VIN"}), 400

    # Add the vehicle to the system
    vehicle_entry = {
        "vin": vin,
        "org": org,
        "manufacturer": vehicle_info['manufacturer'],
        "model": vehicle_info['model'],
        "year": vehicle_info['year']
    }
    vehicles_db.append(vehicle_entry)

    return jsonify(vehicle_entry), 201

if __name__ == '__main__':
    # Start the Flask app
    from threading import Thread

    def run_server():
        app.run(debug=True, use_reloader=False)

    # Run the Flask app in a separate thread
    server_thread = Thread(target=run_server)
    server_thread.start()

    # Now, let's make the request to the /vehicles endpoint
    # Wait for the server to start
    import time
    time.sleep(1)  # Give some time for the server to start

    # Sending the POST request to the /vehicles endpoint
    vehicle_data = {
        "vin": "1HGCM82633A123456",
        "org": "org1"
    }
    response = requests.post("http://127.0.0.1:5000/vehicles", json=vehicle_data)

    # Print the response from the server
    print("Response Status Code:", response.status_code)
    print("Response JSON:", response.json())

   