import time
from collections import defaultdict

class RateLimiter:
    def __init__(self, rate_limit_per_minute):
        self.rate_limit_per_minute = rate_limit_per_minute
        self.timestamps = defaultdict(list)

    def is_allowed(self, key):
        current_time = time.time()
        window_start = current_time - 60  # 60 seconds window
        self.timestamps[key] = [timestamp for timestamp in self.timestamps[key] if timestamp > window_start]
        
        if len(self.timestamps[key]) < self.rate_limit_per_minute:
            self.timestamps[key].append(current_time)
            return True
        return False
