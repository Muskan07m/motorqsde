from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
import requests
from rate_limiter import RateLimiter

app = FastAPI()

NHTSA_API_URL = 'https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/'
NHTSA_API_KEY = 'your_nhtsa_api_key'  # Replace with your NHTSA API key

rate_limiter = RateLimiter(rate_limit_per_minute=5)

class VehicleResponse(BaseModel):
    manufacturer: str
    model: str
    year: str

@app.get("/vehicles/decode/{vin}", response_model=VehicleResponse)
async def decode_vin(vin: str, request: Request):
    client_ip = request.client.host  # Using client IP for rate limiting

    if not rate_limiter.is_allowed(client_ip):
        raise HTTPException(status_code=429, detail="Rate limit exceeded. Try again later.")

    response = requests.get(f'{NHTSA_API_URL}{vin}?format=json&api_key={NHTSA_API_KEY}')
    
    if response.status_code == 200:
        data = response.json()
        vehicle_info = {
            'manufacturer': data.get('Results', [{}])[0].get('Make', 'Unknown'),
            'model': data.get('Results', [{}])[0].get('Model', 'Unknown'),
            'year': data.get('Results', [{}])[0].get('ModelYear', 'Unknown')
        }
        return vehicle_info
    else:
        raise HTTPException(status_code=404, detail="Vehicle not found or invalid VIN")
